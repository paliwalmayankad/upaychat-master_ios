class StringMessage{
  static String network_error="Network not available";
  static String login_successfully="Login successfully";
  static String enter_correct_email="please enter correct email";
  static String enter_correct_emailusrnamemobile="please enter correct email/usernmae/mobile";
  static String enter_correct_password="please enter correct password,password length should be 6 digit";
  static String enter_correct_mobile_number="please enter correct correct Mobile";
  static String username_error="please enter correct Username";
  static String firstname_error="please enter correct firstname";
  static String lastname_error="please enter correct lastname";
  static String id="id";
  static String islogin="islogin";
  static String firstname="firstname";
  static String token="token";
  static String walletbalance="walletbalance";
  static String profileimage="profileimage";
  static String lastname="lastname";
  static String username="username";
  static String email="email";
  static String email_verified_at="email_verified_at";
  static String mobile="mobile";
  static String created_at="created_at";
  static String updated_at="updated_at";
  static String select_image="please select profile picture";
  static String enteroldpassword="please enter correnct oldpasswprd";
  static String enter_correnctnew_password="please enter correct new password";
  static String enter_correctconfirmpassword="password not match";
  static String enter_amount="please enter amount";
  static String enter_correntamount="please correct amount";
  static String networkservererror="Sorry there seems to be a network server error";
  static String dollar="\$";
  static String firsttimelogin="firsttimelogin";
  static String defaultprivacy="defaultprivacy";

}