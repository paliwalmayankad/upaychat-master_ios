import 'package:flutter/cupertino.dart';

class MyColors
{

static const Color base_bg_color= const Color(0xFFF8FFF8);
static const Color base_green_color= const Color(0xFF4EEA4A);
static const Color base_green_color_20= const Color(0xEEE5FFE5);
static const Color light_grey_divider_color= const Color(0xEEE4E8E4);
static const Color hint_text_color= const Color(0xEEE5E5E5);
static const Color grey_color= const Color(0xEE989898);
static const Color navigation_bg_color= const Color(0xEE4D4D4D);
static const Color navigation_textcolor= const Color(0x97979797);


}